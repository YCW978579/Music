<template>
  <div class="search">
    <input type="text"  placeholder="搜索歌曲 歌手">
  </div>

</template>

<script>
import axios from "axios"
	export default {
		data:function(){
		  return{
        search:{},
		  }
		},
		created(){
		  this.getHotKey()
		},
		methods:{
		  getHotKey:function(){
		    var _this = this;
		    axios.get("https://easy-mock.com/mock/5bc1e01b52815755b2b7b2df/search/search").then(function(res){
		      _this.search = res.data.data.search;
		    })
		  }
		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
@import '~@/assets/less/variable.less';
.search{
   width: 100%;
  input{
    background:@color-highlight-background;
    height: 40px;
    margin:20px 5%;
    width: 90%;
    border-radius: 7px;
    color:@color-text-ll;
  }
  input:focus{
    border:none;
    outline: none;
  }
}
</style>
