<template>
    <transition name="slide">
      <Sssinger :title="title" :bgUrl="bgUrl" :songsList="songsList"></Sssinger>  
    </transition>
</template>

<script>
import Sssinger from '@/components/singerDetail'
import {getSingerInfo} from '@/api'
export default {
  data(){
    return{
       list:[],
       title:"",
       bgUrl:"",
       songsList:[]    
    }
  },
  created(){
    this.getSingerInfodetail();      
  },

  methods:{
     getSingerInfodetail:function(){
        let id = this.$route.params.id
       getSingerInfo(id).then(res =>{
         console.log(res); 
         this.title=res.data.singer_name;
         this.bgUrl=`http://y.gtimg.cn/music/photo_new/T001R300x300M000${res.data.singer_mid}.jpg?max_age=2592000`;
         this.songsList=res.data.list;
         
       })    
     },       
  },
  components:{
    Sssinger    
  },
}
</script>

<style lang="less" scoped>
  .slide-enter-active,.slide-leave-active{
    transition:all 0.3s;    
  }
  .slide-enter,.slide-leave{
    transform:translate3d(100%,0,0);    
  }
</style>

