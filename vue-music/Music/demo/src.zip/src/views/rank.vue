<template>
  <div class="rank">
    <div class="box" v-for="(item,index) in rankList" :key="index">
        <div class="pic">
          <img :src="item.picUrl">
        </div>
        <div class="list">
          <p>{{item.topTitle}}</p>
          <p v-for="(itemA,indexA) in item.songList">{{indexA+1}}.<span>{{itemA.songname}}</span>-{{itemA.singername}}</p>
        </div>
    </div>
  </div>
</template>

<script>
import axios from "axios"
	export default {
		data:function(){
		  return{
        rankList:{},
		  }
		},
		created(){
		  this.getTopList()
		},
		methods:{
		  getTopList:function(){
		    var _this = this;
		    axios.get("https://easy-mock.com/mock/5bc1d48252815755b2b7b2ab/rank/rank").then(function(res){
		      _this.rankList = res.data.data.topList;
		    })
		  }
		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
@import '~@/assets/less/variable.less';
  .rank{
    margin-top:20px;
    .box{
      margin-bottom: 20px;
    }
    .pic{
      width: 110px;
      height: 110px;
      display:inline-block;
      margin-left:25px;
      img{
        width: 110px;
        height: 110px;
      }
    }
    .list{
      padding:10px 25px;
      display:inline-block;
      position: absolute;
      p{
        line-height: 22px;
        width: 220px;
        font-size: 13px;
        /*
溢出隐藏
*/
overflow: hidden;
/*
显示省略号
*/
text-overflow: ellipsis;
/*
不换行
*/
white-space: nowrap;

      }
    }
  }
  
</style>
